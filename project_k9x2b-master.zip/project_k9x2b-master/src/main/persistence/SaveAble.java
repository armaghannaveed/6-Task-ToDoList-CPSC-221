package persistence;

import model.ItemList;

import java.io.IOException;

public interface SaveAble {
    void save(ItemList list) throws IOException;
}
