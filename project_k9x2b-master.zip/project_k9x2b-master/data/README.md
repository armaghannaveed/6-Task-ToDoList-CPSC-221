# 6 Task Simple TODO List

## Revolutionize Task Management ##

What, Who And Why?:
- _What will the application do?_ It will enable you to add, remove, and describe upto 6 tasks at most.
- _Who will use it?_ Anyone having Time Management issues, specifically those with ADHD.
- _Why is this project of interest to you?_ I have always struggled with time-management. 
This was until I read an article that suggested to schedule 6 major tasks per day! This program would 
restrict the user on 6 big tasks so they have a more productive day


### User Stories:
- As a user, I want to be able to add a task to my to-do list
- As a user, I want to be able to view the current list of tasks on my to-do list
- As a user, I want to be able to mark a task as complete on my to-do list 
- As a user, I want to be able to set tasks as Urgent or Normal
Extra
- As a user, I want to be able to view the list of completed tasks.
- As a user, I want to be able to be restricted to 6 current tasks.
- As a user, I want to be able to save my to-do list to file.
- As a user, I want to be able to optionally load my to-do list from file when the program starts.

## Instructions for Grader ##
- You can generate the first required Event by typing in the Name, Task Type (either U or N) and then pressing Add.
- You can generate the second required Event by pressing the View Complete Task button.
- You can generate the third required additional Event by typing in the Name and pressing Complete Task.
- The above change can seen by pressing the View Complete Task Button.
- You can generate the fourth additional required Event by pressing the View Current Task Button.
- You can locate my visual component under Let's Do It heading
- You can trigger my audio component once you start the file through main.
- You can save the state of my application by pressing the save tasks button.
- You can reload the state of my application by pressing the load tasks button.

## Phase 4: Task 2 ##
- Item list Class in the model package uses HashMaps to store list of Completed Items and list of Current Items.

## Phase 4: Task 3 ##
- LetsDoItGui has a problem with cohesion, combining adding the audio task and others together.
- The solution to the above problem is to create another class for this audio and then make a call inside LetsDoItGUI.
- In Item List, I was using two methods print current items and print complete items which had the same implement.
- This was a problem with coupling, so I created another method printList() which was called upon by the original 2
methods. To solve cohesion, I created another class itemprinter and placed the printlist static method there.

## Other Problems: Continuation of Phase 4 Task 3 ##
- The ToDoListGui class in ui package has poor cohesion, it should have been subdivided into more classes, like one for
initialization etc. Having inner classes also makes affects the readability of the code. I initially added it to reduce
runtime but given the size of my code. It doesn't sound like a great idea. I also noticed that in the ToDoListGui the 
initialization method was very long, therefore I created a helper method.
- CreateSplashScreen Class had a lot of non-required methods, I fixed this and added an Effects clause.
- LetsDoItGUI wasn't descriptive of the fact that the method was for frame creations. 
- The ItemList class contains the save and load methods, these methods deserve their own class on the basis of coherency
- SetText method wasn't called in the ToDoListGui class therefore I removed it. The setter can be created using IDE in 
the future if needed
- A major change that I made was to refactor the ItemList class methods save and load. The methods were placed in a new
class as a solution to ensure better cohesion. Corresponding change was made to TestSaveAndLoad.


- Additional notes: I replaced the audio file, didn't like the previous one.