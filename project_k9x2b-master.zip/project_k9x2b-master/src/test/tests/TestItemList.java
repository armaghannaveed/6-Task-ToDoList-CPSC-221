package tests;

import model.Item;
import model.ItemList;
import model.NormalItem;
import model.UrgentItem;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TestItemList {
    ItemList itemList1;

    @BeforeEach
    public void runBefore() {
        itemList1 = new ItemList();
    }

    @Test
    public void testAddItem() {
        Item NormalItem1 = new NormalItem("Soccer");
        assertFalse(NormalItem1.getStatus());
        itemList1.addItem(NormalItem1);
        assertTrue(itemList1.containsCurrentItem(NormalItem1));
        itemList1.completeItem("Soccer");
        assertFalse(itemList1.containsCurrentItem(NormalItem1));
        assertTrue(itemList1.completedContainsItem(NormalItem1));
    }

    @Test
    public void testCompleteCurrentItem() {
        Item i1 = new NormalItem("a");
        Item i2 = new NormalItem("x");
        Item i3 = new UrgentItem("z");
        Item i4 = new UrgentItem("g");
        i3.setTaskType();
        i3.changeTaskType();
        i4.setTaskType();

        itemList1.addItem(i1);
        itemList1.addItem(i2);
        itemList1.addItem(i3);
        itemList1.addItem(i4);

        itemList1.completeItem("a");
        itemList1.completeItem("x");
        assertEquals("Name: a   Type: NORMAL" +
                "Name: x   Type: NORMAL", itemList1.printItemsCompleted());

        assertEquals("Name: z   Type: NORMAL" +
                "Name: g   Type: URGENT", itemList1.printItemsCurrent());

    }



    // A Test for more than 6 tasks
    @Test
    public void testTooManyItems() {
        Item i1 = new NormalItem("a");
        Item i2 = new NormalItem("x");
        Item i3 = new UrgentItem("z");
        Item i4 = new UrgentItem("b");
        Item i5 = new UrgentItem("l");
        Item i6 = new UrgentItem("k");
        i6.setStatus();

        Item i7 = new UrgentItem("g");
        i7.setStatus();


        itemList1.addItem(i1);
        itemList1.addItem(i2);
        itemList1.addItem(i3);
        itemList1.addItem(i4);
        itemList1.addItem(i5);
        itemList1.addItem(i6);
        itemList1.completeItem("k");
        itemList1.addItem(i7);

        assertEquals(6, itemList1.currentSize());

    }

    @Test
    public void testPrintingCurrentItems() {
        Item i1 = new NormalItem("a");
        Item i2 = new UrgentItem("x");
        i2.setTaskType();
        itemList1.addItem(i1);
        assertEquals("Name: a   Type: NORMAL", itemList1.printItemsCurrent());
        itemList1.addItem(i2);
        assertEquals("Name: a   Type: NORMAL" +
                "Name: x   Type: URGENT", itemList1.printItemsCurrent());
    }

    @Test
    void testPrintingCompletedItems() {
        Item i1 = new NormalItem("a");
        Item i2 = new UrgentItem("x");
        i2.setTaskType();
        itemList1.addItem(i1);
        itemList1.addItem(i2);
        itemList1.completeItem("a");
        itemList1.completeItem("x");
        assertEquals("Name: a   Type: NORMAL", itemList1.completedItemPrint("a"));
        assertEquals("Name: a   Type: NORMAL" +
                "Name: x   Type: URGENT", itemList1.printItemsCompleted());
    }

}
