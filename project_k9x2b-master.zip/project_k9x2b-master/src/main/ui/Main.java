package ui;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException, InterruptedException {
        CreateSplashScreen splash = new CreateSplashScreen();
        Thread.sleep(2000);
        splash.dispose();
        new LetsDoItGUIframe();
    }
}

