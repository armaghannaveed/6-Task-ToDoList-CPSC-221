package tests;

import persistence.LoadAble;
import model.*;
import org.junit.jupiter.api.*;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

public class TestSaveAndLoad {
    private ItemList listSample;
    private ItemList listLoaded;
    public ItemList loadAble;

    @BeforeEach
    public void runBefore() {
        listLoaded = new ItemList();
        listSample = new ItemList();
    }

    @Test
    public void testLoad() throws IOException {
        loadAble = new ItemList();
        loadAble.load(listSample);
    }

    @Test
    public void testSaveAndLoad() throws IOException {
        Item i1 = new NormalItem("Sleep");
        i1.setStatus();
        i1.setTaskType();
            listSample.addItem(i1);
        Item i2 = new UrgentItem("Soccer");
        i2.setStatus();
        i2.setTaskType();
        listSample.addItem(i2);
        listSample.save(listSample);
        listLoaded.load(listLoaded);
        assertTrue(listLoaded.containsCurrentItem(i2));
        assertTrue(listLoaded.containsCurrentItem(i1));
        assertEquals(2,listLoaded.currentSize());
    }





}
