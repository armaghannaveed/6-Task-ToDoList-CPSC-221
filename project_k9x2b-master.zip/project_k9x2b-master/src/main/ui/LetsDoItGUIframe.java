package ui;

import javax.swing.*;
import java.awt.*;

// Makes the Frame for the GUI
public class LetsDoItGUIframe extends JFrame {
    ToDoListGui toDoListGui;
    PlayMusic playMusic = new PlayMusic();

    // MODIFIES: This
    // EFFECTS: Makes the frame for the app
    public LetsDoItGUIframe() {
        super("Let's Do It");
        this.toDoListGui = new ToDoListGui();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(toDoListGui);
        playMusic.play("./data/old.wav");
        setPreferredSize(new Dimension(500, 800));
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        revalidate();
    }
}
