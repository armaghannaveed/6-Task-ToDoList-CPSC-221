package model;

import java.util.HashMap;
import java.util.Map;

public class ItemPrinter {
    // Phase 4: Task 3
    // EFFECTS: prints out the list
    public static String printList(HashMap<String, Item> items) {
        StringBuffer sbf2 = new StringBuffer();
        for (Map.Entry<String, Item> entry : items.entrySet()) {
            sbf2.append("Name: ").append(entry.getKey()).append("   Type: ")
                    .append(entry.getValue().getTaskType());
        }
        return sbf2.toString();
    }
}
