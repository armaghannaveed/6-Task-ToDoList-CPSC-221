package model;

import javafx.beans.binding.MapExpression;
import persistence.LoadAble;
import persistence.SaveAble;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class SaveAndLoad implements LoadAble, SaveAble {

    //Help Source: WebSearch
    // MODIFIES: this
    // EFFECTS: Loads and adds tasks to the To-Do List
    @Override
    public void load(ItemList list) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get("./data/Our 6 item ToDo list.txt"));
        for (String line : lines) {
            ArrayList<String> parts = giveSpace(line);
            if (parts.get(2).equals("URGENT")) {
                Item urgentItem = new UrgentItem(parts.get(0));
                urgentItem.setStatus();
                urgentItem.setTaskType();
                list.currentItems.put(parts.get(0), urgentItem);
            } else {
                Item normalItem = new NormalItem(parts.get(0));
                normalItem.setStatus();
                normalItem.setTaskType();
                list.currentItems.put(parts.get(0), normalItem);
            }
        }
    }

    // REFERENCE: Obtained the idea for a web search
    // EFFECTS: Gives space between the tasks
    private static ArrayList<String> giveSpace(String line) {
        String[] split = line.split(" ");
        return new ArrayList<>(Arrays.asList(split));
    }

    // MODIFIES: ToDoList file (text file)
    // EFFECTS: saves the item on a text file
    @Override
    public void save(ItemList list) throws IOException {
        PrintWriter printWriter = new PrintWriter("./data/Our 6 item ToDo list.txt", "UTF-8");
        for (Map.Entry<String, Item> entry : list.currentItems.entrySet()) {
            System.out.print("Name: " + entry.getKey());
            System.out.println("  TaskType: " + entry.getValue().getTaskType());

            printWriter.println(entry.getKey() + " " + entry.getValue().getStatus() + " "
                    + entry.getValue().getTaskType());
        }
        printWriter.close();
    }
}
