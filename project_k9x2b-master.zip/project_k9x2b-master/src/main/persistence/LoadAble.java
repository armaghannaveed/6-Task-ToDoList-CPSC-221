package persistence;

import model.ItemList;

import java.io.IOException;

public interface LoadAble {
    void load(ItemList list) throws IOException;
}
