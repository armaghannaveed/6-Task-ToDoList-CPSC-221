package ui;


import model.ItemList;
import model.NormalItem;
import model.UrgentItem;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

// GUI of ToDoList
public class ToDoListGui extends JPanel {
    //Adapted from Oracle's list swing tutorials and
    // other provided class lectures such as the Drawing Player

    private ItemList itemList = new ItemList();
    private String printCompletedListItems = " ";

    JButton addToDoButton;
    JButton loadToDoButton;
    JButton saveToDoButton;
    JButton completeToDoButton;
    JButton viewCurrentButton;
    JButton viewCompleteButton;

    protected JTextField taskName;
    protected JTextField taskType;

    protected JLabel topTitle;
    protected JLabel taskNameTitle;
    protected JLabel taskTypeTitle;
    protected JLabel imageLabel;
    protected JLabel taskListTitle;

    protected JPanel title;
    protected JPanel taskSpecification;
    protected JPanel interactionButtons;
    protected JPanel taskListViewer;


    private static final Color background1 = new Color(241, 250, 123);

    private static final Color textPanelColor = new Color(123, 255, 2);
    private JTextArea textArea;

    // EFFECTS: creates and initializes Task Manager Panel and Functionality
    ToDoListGui() {
        setPreferredSize(new Dimension(500, 600));
        setBorder(new EmptyBorder(13, 13, 13, 13));
        setBackground(background1);
        setLayout(new GridLayout(4, 1));
        GridBagConstraints c = new GridBagConstraints();
        buildTitle();
        buildTaskSpecification();
        buildTaskListViewer();
        buildInteractionButtons();
        buttonCalls();
        add(title);
        add(taskSpecification);
        add(taskListViewer);
        add(interactionButtons);
        setVisible(true);
    }

    // MODIFIES: This
    // EFFECTS: as a helper method creates new buttons
    private void buttonCalls() {
        this.addToDoButton.addActionListener(new AddTaskListener());
        this.taskName.addActionListener(new AddTaskListener());
        this.taskType.addActionListener(new AddTaskListener());
        this.completeToDoButton.addActionListener(new CompleteTaskListner());
        this.taskName.addActionListener(new AddTaskListener());
        this.saveToDoButton.addActionListener(new SaveTaskListListener());
        this.loadToDoButton.addActionListener(new LoadTaskListListener());
        this.viewCurrentButton.addActionListener(new CurrentTaskListner());
        this.viewCompleteButton.addActionListener(new ViewCompleteTaskListner());
    }

    // MODIFIES: This
    //EFFECTS: creates the title and check mark logo in title panel
    private void buildTitle() {
        this.title = new JPanel();
        this.title.setBackground(background1);
        this.title.setLayout(new GridBagLayout());
        this.topTitle = new JLabel("Let's Do It!");
        Font font = new Font("ariel", Font.BOLD, 55);
        this.topTitle.setFont(font);
        placeTitleElements();
    }

    // EFFECTS: lays out elements required for task specification on the appropriate panel
    private void placeTitleElements() {
        GridBagConstraints c = new GridBagConstraints();
        c.gridy = 0;
        c.gridheight = 2;
        title.add(topTitle, c);
        c.gridy = 1;
        try {
            drawIcon();
        } catch (IOException e) {
            e.printStackTrace();
        }
        c.gridy = 3;
        c.gridheight = 1;
        title.add(imageLabel, c);
    }

    // EFFECTS: Calls helper methods and creates a layout for the buttons
    private void buildTaskSpecification() {
        placeButtons();
        taskSpecification.setBackground(background1);
        placeTaskSpecElements();
    }

    // REFERENCE: The image code was helped by Stack Overflow and a program online
    // EFFECTS: draw the image on the ToDo List
    private void drawIcon() throws IOException {
        BufferedImage myPicture = ImageIO.read(new File("./data/bold.png"));
        Image newImage = myPicture.getScaledInstance(200, 100, Image.SCALE_SMOOTH);
        this.imageLabel = new JLabel(new ImageIcon(newImage));
    }


    // EFFECTS: Place the buttons at their appropriate position
    private void placeTaskSpecElements() {
        GridBagConstraints c = new GridBagConstraints();

        c.gridx = 0;
        c.gridy = 0;
        this.taskSpecification.add(this.taskNameTitle, c);

        c.gridx = 1;
        c.gridy = 0;
        this.taskSpecification.add(this.taskTypeTitle, c);

        c.gridx = 0;
        c.gridy = 1;
        this.taskSpecification.add(this.taskName, c);

        c.gridx = 1;
        c.gridy = 1;
        this.taskSpecification.add(this.taskType, c);

        c.gridwidth = 2;
        c.gridx = 0;
        c.gridy = 2;
        c.gridwidth = 2;
        this.taskSpecification.add(this.addToDoButton, c);
    }


    //EFFECTS: initializes and places edit, delete, and save buttons in interactionButtons panel
    private void buildInteractionButtons() {
        initializeInteractionFields();
        Font font = new Font("Times New Roman", Font.ITALIC, 15);
        this.completeToDoButton.setFont(font);
        this.loadToDoButton.setFont(font);
        this.saveToDoButton.setFont(font);
        this.viewCurrentButton.setFont(font);
        this.viewCompleteButton.setFont(font);

        GridBagConstraints c = new GridBagConstraints();

        c.gridx = 0;
        c.gridy = 0;
        this.interactionButtons.add(completeToDoButton, c);

        c.gridx = 1;
        c.gridy = 0;
        this.interactionButtons.add(loadToDoButton, c);

        c.gridx = 0;
        c.gridy = 1;
        this.interactionButtons.add(saveToDoButton, c);

        c.gridx = 1;
        c.gridy = 1;
        this.interactionButtons.add(viewCurrentButton, c);

        c.gridy = 2;
        c.gridx = 0;
        this.interactionButtons.add(viewCompleteButton, c);

    }

    // EFFECTS: initializes fields required for the interaction panel
    private void initializeInteractionFields() {
        this.interactionButtons = new JPanel();
        interactionButtons.setBackground(background1);
        this.interactionButtons.setLayout(new GridBagLayout());
        this.completeToDoButton = new JButton("Complete Task");
        this.loadToDoButton = new JButton("Load List");
        this.saveToDoButton = new JButton("Save Tasks");
        this.viewCurrentButton = new JButton("View Current Task");
        this.viewCompleteButton = new JButton("View Complete Task");
    }

    //EFFECTS: Places the buttons within the panel
    private void placeButtons() {
        this.taskSpecification = new JPanel();
        this.taskSpecification.setLayout(new GridBagLayout());
        this.taskName = new JTextField(10);
        this.taskType = new JTextField(10);
        this.addToDoButton = new JButton("Add Task");
        this.taskNameTitle = new JLabel("Task Name");
        this.taskTypeTitle = new JLabel("Task Type");
        Font font1 = new Font("ariel", Font.BOLD, 15);
        Font font2 = new Font("ariel", Font.ITALIC, 15);
        this.taskNameTitle.setFont(font1);
        this.taskTypeTitle.setFont(font1);
        this.addToDoButton.setFont(font2);
    }

    //EFFECTS: Makes the current To-Do List
    private void buildTaskListViewer() {
        this.taskListViewer = new JPanel();
        taskListViewer.setBackground(textPanelColor);
        Font font = new Font("Century Schoolbook", Font.BOLD, 15);
        Font font2 = new Font("Times New Roman", Font.BOLD, 15);
        taskListViewer.setLayout(new GridLayout(2, 1, 0, 10));
        this.taskListTitle = new JLabel("My Current Tasks:");
        textArea = new JTextArea();
        this.taskListTitle.setFont(font);
        textArea.setFont(font2);
        textArea.append(itemList.printItemsCurrent());
        JScrollPane scroll = new JScrollPane(textArea);
        textArea.setBackground(Color.WHITE);
        taskListTitle.setHorizontalAlignment(JLabel.CENTER);
        taskListViewer.add(taskListTitle);
        taskListViewer.add(scroll);
    }

    // Adds the item to the To-Do list with the given task type
    private class AddTaskListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String name = taskName.getText();
            String choice = taskType.getText();
            if (itemList.currentSize() < 6) {
                if (choice.equals("U")) {
                    UrgentItem urgentItem = new UrgentItem(name);
                    urgentItem.setTaskType();
                    itemList.addItem(urgentItem);
                } else {
                    NormalItem normalItem = new NormalItem(name);
                    normalItem.setTaskType();
                    itemList.addItem(normalItem);
                }
                textArea.append("    New List with Added Item:      " + itemList.printItemsCurrent());
                updateUI();
            } else {
                textArea.append("      Maximum Task Limit Reached      ");
                updateUI();
                System.out.println("Exceeded Max Task Limit");
            }
            System.out.println(itemList.printItemsCurrent());
        }
    }

    // Completes a task
    private class CompleteTaskListner implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String name = taskName.getText();
            itemList.completeItem(name);
            printCompletedListItems = printCompletedListItems + "  " + name;
        }
    }

    // Saves the list
    private class SaveTaskListListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                itemList.save(itemList);
            } catch (IOException i) {
                i.printStackTrace();
            }
        }
    }

    // loads the list
    private class LoadTaskListListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                itemList.load(itemList);
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            System.out.println(itemList.printItemsCurrent());

        }
    }

    // Gives the current list of elements on pressing
    private class CurrentTaskListner implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            textArea.append("    Current Items =   " + itemList.printItemsCurrent());
            updateUI();
        }
    }

    // Gives the completed list of elements on pressing
    private class ViewCompleteTaskListner implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            textArea.append("                            " + " Completed Items: " + printCompletedListItems + " ");
            updateUI();
        }
    }
}