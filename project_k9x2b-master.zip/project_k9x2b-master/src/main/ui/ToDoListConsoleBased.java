package ui;

import model.ItemList;
import model.NormalItem;
import model.UrgentItem;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


// Personal taskManaging application
public class ToDoListConsoleBased extends JFrame {
    private Scanner input;
    private final ItemList itemList = new ItemList();

    // EFFECTS: runs the To-do list application
    public ToDoListConsoleBased() throws IOException {
        runTodoList();
    }


    // MODIFIES: this
    // EFFECTS: process user input
    public void runTodoList() throws IOException {
        boolean keepGoing = true;
        String command = null;
        input = new Scanner(System.in);
        displayMenu();

        while (keepGoing) {
            command = input.next();
            command = command.toLowerCase();

            if (command.equals("q")) {
                keepGoing = false;
            } else {
                processCommand(command);
            }
        }

        System.out.println("\nGoodbye!");
    }

    // EFFECTS: displays menu of options to user
    private void displayMenu() {
        System.out.println("\nSelect from:");
        System.out.println("\ta -> addItem");
        System.out.println("\tc -> mark Item as Complete");
        System.out.println("\tpc -> view list of Current Tasks");
        System.out.println("\tpco -> View List of Completed Tasks");
        System.out.println("\tl -> load the list");
        System.out.println("\tS -> Save the list");
        System.out.println("\tq -> quit");
    }

    // MODIFIES: this
    // EFFECTS: processes user command
    private void processCommand(String command) throws IOException {
        switch (command) {
            case "a":
                addItem();
                break;
            case "pc":
                viewCurrentTask();
                break;
            case "pco":
                viewCompletedTask();
                break;
            case "s":
                saveList();
                break;
            case "l":
                loadList(itemList);
                break;
            case "c":
                completeItem();
                break;
            default:
                System.out.println("Selection not valid...");
                break;
        }
    }

    private void loadList(ItemList itemList) {
        try {
            itemList.load(itemList);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //EFFECTS: Saves the To-Do List
    public void saveList() {
        try {
            itemList.save(itemList);
        } catch (IOException i) {
            i.printStackTrace();
        }
    }


    //REQUIRES: An Existing Element to be completed
    //MODIFIES: This
    //EFFECTS: marks an item as complete
    public void completeItem() {
        System.out.println("Enter Name of Task to be Completed?");
        String name = input.next();
        itemList.completeItem(name);
        displayMenu();
    }

    //EFFECTS: Displays the completed Tasks
    public void viewCompletedTask() {
        System.out.println(itemList.printItemsCompleted());
        displayMenu();
    }

    //EFFECTS: Displays the current Tasks
    public void viewCurrentTask() {
        System.out.println(itemList.printItemsCurrent());
        displayMenu();
    }

    //MODIFIES: This
    //EFFECTS: adds task to the list if the number of task are less than Maximum Allowed
    public void addItem() {
        if (itemList.currentSize() <= itemList.maxSize) {
            System.out.println("Enter Name to be added");
            String name = input.next();
            System.out.println("N for Normal or U for Urgent?");
            String choice = input.next();
            if (choice.equals("U")) {
                UrgentItem urgentItem = new UrgentItem(name);
                urgentItem.setTaskType();
                itemList.addItem(urgentItem);
            } else {
                NormalItem normalItem = new NormalItem(name);
                normalItem.setTaskType();
                itemList.addItem(normalItem);
            }
            displayMenu();
        } else {
            System.out.println("Exceeded Max Task Limit");
        }

    }
}

