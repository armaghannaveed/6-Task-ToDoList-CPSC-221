package model;

// Deals with Urgent items
public class UrgentItem extends Item {
    public UrgentItem(String name) {
        super(name);
    }

    // MODIFIES: this
    // EFFECTS: sets taskType to "Urgent"
    @Override
    public void setTaskType() {
        this.taskType = "URGENT";
    }
}
