package tests;

import model.Item;
import model.NormalItem;
import model.UrgentItem;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TestItem {
    NormalItem I1;
    UrgentItem I3;


    @BeforeEach
    public void runBefore() {
        I1 = new NormalItem("CPSC 210 Lab");
        I3 = new UrgentItem("CPSC 210 Final Project");
    }

    @Test
    public void testNormalConstructor() {
        I1.setStatus();
        assertFalse(I1.getStatus());
        I1.changeCurrentStatus();
        assertTrue(I1.getStatus());
        I1.changeCurrentStatus();
        assertFalse(I1.getStatus());
        I1.setTaskType();
        assertEquals("NORMAL", I1.getTaskType());
    }

    @Test
    public void testUrgentConstructor() {
        assertEquals("CPSC 210 Final Project", I3.getName());
        I3.setTaskType();
        assertEquals("URGENT", I3.getTaskType());
        I3.changeCurrentStatus();
        assertTrue(I3.getStatus());
    }


    @Test void testChangeTaskType() {
        I1.setTaskType();
        I3.setTaskType();
        assertEquals("URGENT", I3.getTaskType());
        I3.changeTaskType();
        assertEquals("NORMAL",I3.getTaskType());
        assertEquals("NORMAL",I1.getTaskType());
        I1.changeTaskType();
        assertEquals("URGENT",I1.getTaskType());
    }


}
