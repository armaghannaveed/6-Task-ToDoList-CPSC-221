package ui;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;

//Plays Music
public class PlayMusic {

    //EFFECTS: Plays the starting Sound for the Program
    public static void play(String file) {
        File f = new File(file);
        if (f.canRead()) {
            try {
                Clip clip = AudioSystem.getClip();
                AudioInputStream inputStream = AudioSystem.getAudioInputStream(f);
                clip.open(inputStream);
                clip.start();
            } catch (Exception e) {
                //Do nothing
            }
        }
    }
}
