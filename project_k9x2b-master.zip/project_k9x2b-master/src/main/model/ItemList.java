package model;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static model.ItemPrinter.printList;

// A List of Items
public class ItemList {

    public HashMap<String, Item> currentItems;
    private HashMap<String, Item> completedItems;
    private SaveAndLoad saveAndLoad = new SaveAndLoad();
    public int maxSize = 6;

    //EFFECTS: Creates a list of items containing Current and Completed items
    public ItemList() {
        completedItems = new HashMap<>();
        currentItems = new HashMap<>();
    }


    //Will create an exception here!
    //REQUIRES: The number of items should not be more than maxSize
    //MODIFIES: this
    //EFFECTS: adds item to current List
    public void addItem(Item addingItem) {
        if (currentItems.size() <= maxSize) {
            currentItems.put(addingItem.getName(), addingItem);
        }
    }

    // REQUIRES: The item completed should be a valid item in the current list
    // MODIFIES: This
    //EFFECTS: Removes the item from current and adds it to completed
    public void completeItem(String completedItem) {
        currentItems.get(completedItem).changeCurrentStatus();
        completedItems.put(completedItem, currentItems.get(completedItem));
        currentItems.remove(completedItem);
    }

    // EFFECTS: Prints the item that was completed
    // According to instructions will complete it fully do it in the next Phase
    public String completedItemPrint(String name) {
        Item item = completedItems.get(name);
        StringBuffer sbf1 = new StringBuffer("Name: ");
        sbf1.append(item.getName()).append("   Type: ").append(item.taskType);
        return sbf1.toString();
    }

    // REQUIRES: List > 1
    //EFFECTS: prints out the list of completed
    // According to instructions will complete it fully in the next Phase
    public String printItemsCompleted() {
        return ItemPrinter.printList(completedItems);
    }

    // REQUIRES: List > 1
    //EFFECTS: prints out the list of current
    // According to instructions will complete it fully in the next Phase
    public String printItemsCurrent() {
        return ItemPrinter.printList(currentItems);
    }



    //EFFECTS: returns true if current list contains item
    public boolean containsCurrentItem(Item item) {
        return currentItems.containsValue(item);
    }

    //EFFECTS: returns true if completed list contains item
    public boolean completedContainsItem(Item item) {
        return completedItems.containsValue(item);
    }

    //EFFECTS: Gives the size of the list of current items
    public int currentSize() {
        return currentItems.size();
    }

    //EFFECTS: Returns the current items in the list
    public HashMap<String, Item> getCurrent() {
        return currentItems;
    }

    //Help Source: WebSearch
    // MODIFIES: this
    // EFFECTS: Loads and adds tasks to the To-Do List
    public void load(ItemList list) throws IOException {
        saveAndLoad.load(list);
    }

    // MODIFIES: ToDoList file (text file)
    // EFFECTS: saves the item on a text file
    public void save(ItemList list) throws IOException {
        saveAndLoad.save(list);
    }

    // REFERENCE: Obtained the idea for a web search
    // EFFECTS: Gives space between the tasks
    private static ArrayList<String> giveSpace(String line) {
        String[] split = line.split(" ");
        return new ArrayList<>(Arrays.asList(split));
    }

}
