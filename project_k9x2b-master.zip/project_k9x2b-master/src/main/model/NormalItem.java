package model;

public class NormalItem extends Item {

    // Deals with Normal Items
    public NormalItem(String name) {
        super(name);
    }

    //MODIFIES: this
    //EFFECTS: sets status to "Normal"
    @Override
    public void setTaskType() {
        this.taskType = "NORMAL";
    }
}
