package model;

import java.util.Objects;

// Provides the specifications required for an item. It's a super type which is extended by different types of methods
public abstract class Item {

    //Fields in protected so that it can only be accessed by subtypes
    protected String name;
    protected Boolean status;
    protected String taskType;
    //Incomplete =false , Complete= True

    //REQUIRES: Name (character_length > 0)
    //MODIFIES: This
    //EFFECT: Creates a new item in the todo list
    public Item(String name) {
        this.name = name;
        this.status = false;
        this.taskType = "NORMAL";
    }

    //MODIFIES: this
    //EFFECTS: sets TaskType to either Normal or Urgent
    public abstract void setTaskType();

    // MODIFIES: this
    // EFFECTS: sets status to "Incomplete"
    public void setStatus() {
        this.status = false;
    }

    //MODIFIES: This
    //EFFECT: Change status from Incomplete to Complete and vice-versa
    public void changeCurrentStatus() {
        this.status = !getStatus();
    }

    //EFFECT: Returns the Status
    public boolean getStatus() {
        return status;
    }

    //EFFECT: Returns the type
    public String getTaskType() {
        return taskType;
    }

    //MODIFIES: This
    //EFFECT: Change Task Type from Urgent to Normal and ViceVersa
    public void changeTaskType() {
        if (taskType.equals("URGENT")) {
            this.taskType = "NORMAL";
        } else {
            this.taskType = "URGENT";
        }
    }

    // To make the items match using their Keys
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Item)) {
            return false;
        }
        Item item = (Item) o;
        return name.equals(item.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    //EFFECT: return item name
    public String getName() {
        return name;
    }
}
